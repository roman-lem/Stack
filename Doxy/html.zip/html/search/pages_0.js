var searchData=
[
  ['stack_20task_103',['Stack task',['../index.html',1,'']]]
];

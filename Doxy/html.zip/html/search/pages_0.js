var searchData=
[
  ['stack_20task_39',['Stack task',['../index.html',1,'']]]
];

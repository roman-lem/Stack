var searchData=
[
  ['t_5fstackconstruct_40',['T_StackConstruct',['../_stack_test_8c.html#a356291568b2e999f1791eac04a627840',1,'T_StackConstruct():&#160;StackTest.c'],['../_stack_test_8h.html#a356291568b2e999f1791eac04a627840',1,'T_StackConstruct():&#160;StackTest.c']]],
  ['t_5fstackdestruct_41',['T_StackDestruct',['../_stack_test_8c.html#a180cf2e4154d726c7728a804bb09fb8f',1,'T_StackDestruct():&#160;StackTest.c'],['../_stack_test_8h.html#a180cf2e4154d726c7728a804bb09fb8f',1,'T_StackDestruct():&#160;StackTest.c']]],
  ['t_5fstackdump_42',['T_StackDump',['../_stack_test_8c.html#a9d157a9dfc52339ad56699ebf4d898e7',1,'T_StackDump():&#160;StackTest.c'],['../_stack_test_8h.html#a9d157a9dfc52339ad56699ebf4d898e7',1,'T_StackDump():&#160;StackTest.c']]],
  ['t_5fstackok_43',['T_StackOK',['../_stack_test_8c.html#a6242d9c2c6d256cd715f915fd6c9b5cf',1,'T_StackOK():&#160;StackTest.c'],['../_stack_test_8h.html#a6242d9c2c6d256cd715f915fd6c9b5cf',1,'T_StackOK():&#160;StackTest.c']]],
  ['t_5fstackpop_44',['T_StackPop',['../_stack_test_8c.html#aaa162acdc74cb080bd68159e95d5ce2b',1,'T_StackPop():&#160;StackTest.c'],['../_stack_test_8h.html#aaa162acdc74cb080bd68159e95d5ce2b',1,'T_StackPop():&#160;StackTest.c']]],
  ['t_5fstackpush_45',['T_StackPush',['../_stack_test_8c.html#a2053d568c4196c75edb86fe22ae728ad',1,'T_StackPush():&#160;StackTest.c'],['../_stack_test_8h.html#a2053d568c4196c75edb86fe22ae728ad',1,'T_StackPush():&#160;StackTest.c']]],
  ['test_2ec_46',['Test.c',['../_test_8c.html',1,'']]],
  ['top_47',['top',['../structstack.html#a2d100511cad42e140cbbe2863cab8c8c',1,'stack']]]
];

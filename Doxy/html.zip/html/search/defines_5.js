var searchData=
[
  ['k_93',['k',['../c_text_8h.html#a13b230ea1d237595fb236c951a0849e0',1,'cText.h']]]
];

var searchData=
[
  ['d_14',['d',['../c_text_8h.html#a2530554172d8629149ec56816eeaa947',1,'cText.h']]]
];

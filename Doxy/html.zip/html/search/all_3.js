var searchData=
[
  ['poison_5fnumber_3',['POISON_NUMBER',['../_stack_struct_8h.html#a8fa782e27dd730df15898d22cf3bbaba',1,'StackStruct.h']]]
];

var searchData=
[
  ['y_51',['y',['../c_text_8h.html#a0ed6a908288e0cd87f79c1b5ab56d07c',1,'cText.h']]]
];

var searchData=
[
  ['r_24',['r',['../c_text_8h.html#a62969232668331297e2dca1ae2ddd10d',1,'cText.h']]]
];

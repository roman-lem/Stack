var searchData=
[
  ['buf_0',['buf',['../structstack.html#ab754ec8078e0021303bed12ac4aff5e9',1,'stack']]]
];

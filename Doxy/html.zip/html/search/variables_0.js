var searchData=
[
  ['buf_74',['buf',['../structstack.html#af78099467725fbf43affb1a4ef491d1b',1,'stack']]]
];

var searchData=
[
  ['b_78',['b',['../c_text_8h.html#ab2d05693952610f937e5acb3c4a8fa1b',1,'cText.h']]],
  ['bd_79',['bd',['../c_text_8h.html#a69fd04aad1f8dd9c821f497754295f7a',1,'cText.h']]],
  ['bgb_80',['bgb',['../c_text_8h.html#a0e906eb7cdd1977913232f38fb8f25b5',1,'cText.h']]],
  ['bgg_81',['bgg',['../c_text_8h.html#a3de80645a061064b35d42ded3252fc6d',1,'cText.h']]],
  ['bgk_82',['bgk',['../c_text_8h.html#a8198f1704991c6c3b6f755b9f0960d89',1,'cText.h']]],
  ['bglb_83',['bglb',['../c_text_8h.html#a1cd324f94209116a05bf32ce2470a3aa',1,'cText.h']]],
  ['bgp_84',['bgp',['../c_text_8h.html#a97604ab698a38f12e96b510998f0780c',1,'cText.h']]],
  ['bgr_85',['bgr',['../c_text_8h.html#ad9e60a3f64190ca78a8773d04bbe3e00',1,'cText.h']]],
  ['bgw_86',['bgw',['../c_text_8h.html#aeacbbbe7eaad65e0cb35d3e110deb0f9',1,'cText.h']]],
  ['bgy_87',['bgy',['../c_text_8h.html#aa2a3b13a5411e887e8f52ec9e21551b0',1,'cText.h']]],
  ['bl_88',['bl',['../c_text_8h.html#af2fd05c57257a8c2eee11a1d65918075',1,'cText.h']]]
];

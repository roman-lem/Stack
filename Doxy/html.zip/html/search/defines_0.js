var searchData=
[
  ['poison_5fnumber_38',['POISON_NUMBER',['../_stack_struct_8h.html#a8fa782e27dd730df15898d22cf3bbaba',1,'StackStruct.h']]]
];

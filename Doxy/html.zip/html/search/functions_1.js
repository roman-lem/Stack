var searchData=
[
  ['stackconstruct_28',['StackConstruct',['../_stack_func_8c.html#ae61f4a4e1550f7f73d6d9a4978d9f5c6',1,'StackConstruct(stack_t *stack, int capacity):&#160;StackFunc.c'],['../_stack_func_8h.html#ae61f4a4e1550f7f73d6d9a4978d9f5c6',1,'StackConstruct(stack_t *stack, int capacity):&#160;StackFunc.c']]],
  ['stackdestruct_29',['StackDestruct',['../_stack_func_8c.html#aa4fd53309147a8b54f63c4924333c2be',1,'StackDestruct(stack_t *stack):&#160;StackFunc.c'],['../_stack_func_8h.html#aa4fd53309147a8b54f63c4924333c2be',1,'StackDestruct(stack_t *stack):&#160;StackFunc.c']]],
  ['stackdump_30',['StackDump',['../_stack_func_8c.html#a0c1dc76e5ea5934e1bb9c11b8f8373bc',1,'StackDump(const stack_t *stack):&#160;StackFunc.c'],['../_stack_func_8h.html#a0c1dc76e5ea5934e1bb9c11b8f8373bc',1,'StackDump(const stack_t *stack):&#160;StackFunc.c']]],
  ['stackok_31',['StackOK',['../_stack_func_8c.html#ad223c2faa714921c169112ed7f98100a',1,'StackOK(const stack_t *stack):&#160;StackFunc.c'],['../_stack_func_8h.html#ad223c2faa714921c169112ed7f98100a',1,'StackOK(const stack_t *stack):&#160;StackFunc.c']]],
  ['stackpop_32',['StackPop',['../_stack_func_8c.html#a512565efa742701b112f0af9115c2ec5',1,'StackPop(stack_t *stack, int *element):&#160;StackFunc.c'],['../_stack_func_8h.html#a512565efa742701b112f0af9115c2ec5',1,'StackPop(stack_t *stack, int *element):&#160;StackFunc.c']]],
  ['stackpush_33',['StackPush',['../_stack_func_8c.html#a3fe2e28c03d007be25a2b6913db9c126',1,'StackPush(stack_t *stack, int element):&#160;StackFunc.c'],['../_stack_func_8h.html#a3fe2e28c03d007be25a2b6913db9c126',1,'StackPush(stack_t *stack, int element):&#160;StackFunc.c']]]
];

var searchData=
[
  ['stack_52',['stack',['../structstack.html',1,'']]]
];

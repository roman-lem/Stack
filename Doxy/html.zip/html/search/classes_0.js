var searchData=
[
  ['stack_20',['stack',['../structstack.html',1,'']]]
];

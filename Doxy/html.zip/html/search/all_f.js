var searchData=
[
  ['v_49',['v',['../c_text_8h.html#a38bf1e5e0427bdeba2b469eea9befc23',1,'cText.h']]]
];

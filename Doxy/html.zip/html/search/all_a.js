var searchData=
[
  ['p_22',['p',['../c_text_8h.html#ade66e4ccafbc33b117610bbc0d85feb0',1,'cText.h']]],
  ['poison_5fnumber_23',['POISON_NUMBER',['../source_2_stack_struct_8h.html#a8fa782e27dd730df15898d22cf3bbaba',1,'POISON_NUMBER():&#160;StackStruct.h'],['../_stack_struct_8h.html#a8fa782e27dd730df15898d22cf3bbaba',1,'POISON_NUMBER():&#160;StackStruct.h']]]
];

var searchData=
[
  ['stack_5ft_37',['stack_t',['../_stack_struct_8h.html#a4626fc2f61bed7e5faec5b4f459a02f7',1,'StackStruct.h']]]
];

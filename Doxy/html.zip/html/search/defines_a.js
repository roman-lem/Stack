var searchData=
[
  ['ul_99',['ul',['../c_text_8h.html#af94c3c5842a759263f614d6410095d7f',1,'cText.h']]]
];

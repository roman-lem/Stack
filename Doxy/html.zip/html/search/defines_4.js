var searchData=
[
  ['i_92',['i',['../c_text_8h.html#a08582ce460e3d5e1cf0b7fea017d608e',1,'cText.h']]]
];

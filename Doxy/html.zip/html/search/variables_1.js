var searchData=
[
  ['capacity_35',['capacity',['../structstack.html#a152808cfa48be742febaf4ced9e08c40',1,'stack']]]
];

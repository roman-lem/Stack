var searchData=
[
  ['lb_19',['lb',['../c_text_8h.html#ace2edd29fb317368936179b2ebf1593d',1,'cText.h']]]
];

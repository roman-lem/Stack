var searchData=
[
  ['g_91',['g',['../c_text_8h.html#a167d2c0ec9b943d55f2124f7442b2f6d',1,'cText.h']]]
];
